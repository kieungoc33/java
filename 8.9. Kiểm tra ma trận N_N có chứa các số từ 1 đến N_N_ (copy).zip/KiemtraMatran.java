/**
 * Chương trình nhập một số nguyên dương n và ma trận nguyên A kích thước n x n 
 * sau đó kiểm tra xem các phần tử của ma trận có giá trị từ 1 đến n*n hay không
 * Nếu đúng in ra màn hình thông báo "YES", nếu sai, in ra thông báo "NO"
 * **/
import java.util.Scanner;
public class KiemtraMatran{
    public static String kt(int A[][]){
        int n = A.length;
        int s = ( n * n) * (n* n + 1) / 2;
        for ( int i = 0; i < n ; i++){
            for ( int j = 0; j < n; j++){
                s = s - A[i][j];
            }
        }
        if ( s == 0) {
        return "YES";
        }
        else {
        	return "NO";
        }
        
    }
    // viết mã lệnh ở đây
    public static void main ( String[] args){
        Scanner sc = new Scanner (System.in);
        int n = sc.nextInt();
        int [][]A = new int [n][n];
        
        for (int i = 0 ; i < n ; i++){
            for ( int j = 0; j < n; j++){
                A [i][j] = sc.nextInt();
                
            }

        }
        System.out.print(kt(A));
        
    }	 	  	   	      		      	      	 	
    
}